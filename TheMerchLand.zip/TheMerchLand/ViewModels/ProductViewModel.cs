﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TheMerchLand.Models;

namespace TheMerchLand.ViewModels
{
    public class ProductViewModel
    {
        public IEnumerable<Product> products { get; set; }

        public string CurrentCategory { get; set; }

    }
}
