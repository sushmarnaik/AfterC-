﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheMerchLand.Migrations
{
    public partial class Initial_Migration3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "categories",
                columns: new[] { "Catid", "Catname", "Description" },
                values: new object[,]
                {
                    { 1, "Pencil1", "Graphite pencils" },
                    { 2, "Acrylic Paint", "Basic" },
                    { 3, "Paint brush", "Plastic bristles" }
                });

            migrationBuilder.InsertData(
                table: "products",
                columns: new[] { "Pid", "Catid", "ImageBigUrl", "ImageSmallUrl", "IsTrending", "Pinfo", "Pname", "Pprice", "categoryCatid" },
                values: new object[,]
                {
                    { 1, 1, null, "~/Images/tshirt1.jpg", false, "Set of 4", "Camel HB Pencil", 100, null },
                    { 2, 2, null, "~/Images/tshirt2.jpg", false, "Set of 10", "Mont Marte Acrylic colour", 600, null },
                    { 3, 3, null, "~/Images/tshirt3.jpg", false, "Set of 3", "Brustro brushes", 500, null }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "categories",
                keyColumn: "Catid",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "categories",
                keyColumn: "Catid",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "categories",
                keyColumn: "Catid",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 3);
        }
    }
}
