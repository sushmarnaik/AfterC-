﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheMerchLand.Migrations
{
    public partial class Initial_Migration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "categories",
                columns: table => new
                {
                    Catid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Catname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_categories", x => x.Catid);
                });

            migrationBuilder.CreateTable(
                name: "products",
                columns: table => new
                {
                    Pid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Pname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Pinfo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ImageBigUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ImageSmallUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Pprice = table.Column<int>(type: "int", nullable: false),
                    IsTrending = table.Column<bool>(type: "bit", nullable: false),
                    Catid = table.Column<int>(type: "int", nullable: false),
                    categoryCatid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_products", x => x.Pid);
                    table.ForeignKey(
                        name: "FK_products_categories_categoryCatid",
                        column: x => x.categoryCatid,
                        principalTable: "categories",
                        principalColumn: "Catid",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_products_categoryCatid",
                table: "products",
                column: "categoryCatid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "products");

            migrationBuilder.DropTable(
                name: "categories");
        }
    }
}
