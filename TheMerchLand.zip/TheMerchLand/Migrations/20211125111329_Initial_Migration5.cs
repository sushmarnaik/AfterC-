﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheMerchLand.Migrations
{
    public partial class Initial_Migration5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 1,
                columns: new[] { "ImageSmallUrl", "IsTrending", "Pinfo", "Pname", "Pprice" },
                values: new object[] { "~/Images/tshirt1.jpg", true, "Wolverine", "Tshirt 1", 500 });

            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 2,
                columns: new[] { "ImageSmallUrl", "Pinfo", "Pname" },
                values: new object[] { "~/Images/tshirt2.jpg", "Marvel", "Tshirt 2" });

            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 3,
                columns: new[] { "ImageSmallUrl", "IsTrending", "Pinfo", "Pname" },
                values: new object[] { "~/Images/tshirt3.jpg", true, "Marvel", "Tshirt 3" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 1,
                columns: new[] { "ImageSmallUrl", "IsTrending", "Pinfo", "Pname", "Pprice" },
                values: new object[] { "~/Images/art1.jpg", false, "Set of 4", "Camel HB Pencil", 100 });

            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 2,
                columns: new[] { "ImageSmallUrl", "Pinfo", "Pname" },
                values: new object[] { "~/Images/art2.jpg", "Set of 10", "Mont Marte Acrylic colour" });

            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 3,
                columns: new[] { "ImageSmallUrl", "IsTrending", "Pinfo", "Pname" },
                values: new object[] { "~/Images/art3.jpg", false, "Set of 3", "Brustro brushes" });
        }
    }
}
