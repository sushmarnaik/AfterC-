﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheMerchLand.Migrations
{
    public partial class migration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 1,
                column: "Pname",
                value: "Tshirt 1 db");

            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 2,
                column: "Pname",
                value: "Tshirt 2 db");

            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 3,
                column: "Pname",
                value: "Tshirt 3 db");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 1,
                column: "Pname",
                value: "Tshirt 1");

            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 2,
                column: "Pname",
                value: "Tshirt 2");

            migrationBuilder.UpdateData(
                table: "products",
                keyColumn: "Pid",
                keyValue: 3,
                column: "Pname",
                value: "Tshirt 3");
        }
    }
}
