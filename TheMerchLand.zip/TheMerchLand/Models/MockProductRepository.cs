﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMerchLand.Models
{
    public class MockProductRepository:IProductRepository

    {
        List<Product> _products;
        List<Product> _trendingproducts;

        public MockProductRepository()
        {
            _products = new List<Product>
            {
                new Product{Pid=1,Pname="Tshirt 1",Pinfo="Wolverine",Pprice=500,ImageSmallUrl="~/Images/tshirt1.jpg" ,Catid=1,IsTrending=true},
            new Product{Pid=2,Pname="Tshirt 2",Pinfo="Marvel",Pprice=600,ImageSmallUrl="~/Images/tshirt2.jpg",Catid=2,IsTrending=false},
            new Product{Pid=3,Pname="Tshirt 3",Pinfo="Marvel",Pprice=500,ImageSmallUrl="~/Images/tshirt3.jpg", Catid = 3,IsTrending=true},

            };
            _trendingproducts= AllProducts.Where(p => p.IsTrending == true).ToList();
        }
        public IEnumerable<Product> AllProducts
        {
            get
            { return _products; }
        }

        public IEnumerable<Product> GetTrendingProducts
        {
            get
            { return _trendingproducts; }
        }





        //public IEnumerable<Product> GetTrendingProducts()
        //{
        //    return AllProducts.Where(p => p.IsTrending = true);
        //}

        public Product GetProductById(int Pid)
        {
            return AllProducts.FirstOrDefault(p => p.Pid == Pid);
        }
    }
}
