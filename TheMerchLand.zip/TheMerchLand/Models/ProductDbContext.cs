﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMerchLand.Models
{
    public class ProductDbContext:DbContext
    {
        public ProductDbContext(DbContextOptions<ProductDbContext> options) : base(options)
        {

        }

        public DbSet<Product> products { get; set; }
        public DbSet<Category> categories { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(new Category { Catid = 1, Catname = "Pencil1", Description = "Graphite pencils" },
                new Category { Catid = 2, Catname = "Acrylic Paint", Description = "Basic" },
                new Category { Catid = 3, Catname = "Paint brush", Description = "Plastic bristles" }
                //,new Category { Catid = 4, Catname = "Washi Tape", Description = "Colourful tapes" }
                );

            modelBuilder.Entity<Product>().HasData(new Product { Pid = 1, Pname = "Tshirt 1 db", Pinfo = "Wolverine", Pprice = 500, ImageSmallUrl = "~/Images/tshirt1.jpg", Catid = 1, IsTrending = true },
            new Product { Pid = 2, Pname = "Tshirt 2 db", Pinfo = "Marvel", Pprice = 600, ImageSmallUrl = "~/Images/tshirt2.jpg", Catid = 2, IsTrending = false },
            new Product { Pid = 3, Pname = "Tshirt 3 db", Pinfo = "Marvel", Pprice = 500, ImageSmallUrl = "~/Images/tshirt3.jpg", Catid = 3, IsTrending = true }
);
        }
    }
}
