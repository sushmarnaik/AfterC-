﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMerchLand.Models
{
    public class CategoryRepository:ICategoryRepository
    {
        private readonly ProductDbContext _productDbContext;

        public CategoryRepository(ProductDbContext productDbContext)
        {
            _productDbContext = productDbContext;
        }

        public IEnumerable<Category> AllCategories => _productDbContext.categories;
    }
}
