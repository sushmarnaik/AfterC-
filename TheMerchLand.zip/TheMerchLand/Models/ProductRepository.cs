﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMerchLand.Models
{
    public class ProductRepository:IProductRepository
    {
        private readonly ProductDbContext _productDbContext;

        public ProductRepository(ProductDbContext productDbContext)
        {
            _productDbContext = productDbContext;
        }
        public IEnumerable<Product> AllProducts
        {
            get
            {
                return _productDbContext.products.Include(c => c.category);
            }
        }

        public IEnumerable<Product> GetTrendingProducts => throw new NotImplementedException();

        //public IEnumerable<Product> GetTrendingProducts
        //{
        //    get
        //    {
        //        return _productDbContext.products.Include(p => p.IsTrending == true);
        //    }
        //}

        public Product GetProductById(int pid)
        {
            return AllProducts.FirstOrDefault(p => p.Pid == pid);
        }
    }
}
