﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMerchLand.Models
{
    public interface IProductRepository
    {
        public IEnumerable<Product> AllProducts { get; }

        public IEnumerable<Product> GetTrendingProducts { get; }
        Product GetProductById(int Pid);
    }
}
