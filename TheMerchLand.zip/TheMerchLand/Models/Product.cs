﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TheMerchLand.Models
{
    public class Product
    {
        [Key]
        public int Pid { get; set; }
        public string Pname { get; set; }
        public string Pinfo { get; set; }
        public string ImageBigUrl { get; set; }
        public string ImageSmallUrl { get; set; }
        public int Pprice { get; set; }
        public bool IsTrending { get; set; }
        public int Catid { get; set; }
        public Category category { get; set; }
    }
}
