﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMerchLand.Models
{
    public class MockCategoryRepository:ICategoryRepository
    {
        public IEnumerable<Category> AllCategories =>
            new List<Category>
            {
                new Category{Catid=1,Catname="Pencil1",Description="Graphite pencils"},
                new Category{Catid=2,Catname="Acrylic Paint",Description="Basic"},
                new Category{Catid=3,Catname="Paint brush",Description="Plastic bristles"}
            };
    }
}
