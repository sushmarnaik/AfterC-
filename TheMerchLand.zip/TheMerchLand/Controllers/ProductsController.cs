﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TheMerchLand.Models;
using TheMerchLand.ViewModels;

namespace TheMerchLand.Controllers
{
    
    public class ProductsController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly ICategoryRepository _categoryRepository;
        public ProductsController(IProductRepository productRepository,ICategoryRepository categoryRepository)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
        }
        public IActionResult Index(string search,int catid)
        {
            IEnumerable<Product> productslist;
            string currentCat;

            if (catid == 0)
            {
                productslist = _productRepository.AllProducts.OrderBy(p => p.Pid);
                currentCat = "All Products";
            }
            else
            {
                productslist = _productRepository.AllProducts.Where(p => p.Catid == catid).OrderBy(p => p.Pid);
                currentCat = _categoryRepository.AllCategories.FirstOrDefault(c => c.Catid == catid).Catname;
            }
            

            if (!String.IsNullOrEmpty(search))
            {
                var PVModel2 = new ProductViewModel
                {
                    products = _productRepository.AllProducts.Where(p => p.Pname.ToLower().Contains(search.ToLower()) || search == null || p.Pinfo.ToLower().Contains(search.ToLower()) )
                };

                //PVModel2.products = PVModel2.products.Where(p => p.Pname.ToString() == search.ToLower() || search == null);
                return View(PVModel2);
                //return View(_productRepository.AllProducts.Where(p => p.Pname.ToLower() == search.ToLower() || search == null).ToList());
            }

            return View(new ProductViewModel
            {
                products = productslist,
                CurrentCategory = currentCat
            }
                );

        }

        public IActionResult Details(int id)
        {
            var productmodel = _productRepository.AllProducts.Single(p => p.Pid == id);
            return View(productmodel);
        }
    }
}
