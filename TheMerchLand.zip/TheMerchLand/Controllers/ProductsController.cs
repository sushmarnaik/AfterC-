﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TheMerchLand.Models;

namespace TheMerchLand.Controllers
{
    
    public class ProductsController : Controller
    {
        private readonly IProductRepository _productRepository;
        public ProductsController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
        public IActionResult Index()
        {
            var productmodel = from p in _productRepository.AllProducts
                               select p;


            return View(productmodel);
        }
    }
}
